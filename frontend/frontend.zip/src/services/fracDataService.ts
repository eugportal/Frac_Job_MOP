// Service abstraction. Initially backed by localStorage; a future API can replace these implementations.

import type { FracDataService, FracFormData, SubmissionResult } from '@/types/fracTypes';
import { computeJobCostBreakdown } from '@/utils/calculations';
import { generateReferenceNumber } from '@/utils/formatters';
import {
  clearDraftFromStorage,
  loadDraftFromStorage,
  saveSubmission,
  saveDraftToStorage,
} from '@/utils/storage';

const apiUrl = (import.meta.env.VITE_API_URL ?? 'http://localhost:3001').replace(/\/$/, '');

async function saveToApi(accessToken: string, path: string, data: FracFormData): Promise<SubmissionResult> {
  const response = await fetch(`${apiUrl}${path}`, { method: 'POST', headers: { Authorization: `Bearer ${accessToken}`, 'Content-Type': 'application/json' }, body: JSON.stringify(data) });
  const payload = await response.json().catch(() => ({})) as { message?: string; job?: SubmissionResult };
  if (!response.ok || !payload.job) throw new Error(payload.message ?? 'Unable to save the frac job.');
  return payload.job;
}

export function createFracDataService(accessToken: string): FracDataService {
  return {
    async saveDraft(data) { await saveToApi(accessToken, '/api/frac-jobs/drafts', data); },
    async loadDraft() { return null; },
    async clearDraft() { clearDraftFromStorage(); },
    async submit(data) { const job = await saveToApi(accessToken, '/api/frac-jobs/submit', data); clearDraftFromStorage(); return job; },
  };
}

export const localFracDataService: FracDataService = {
  async saveDraft(data: FracFormData): Promise<void> {
    saveDraftToStorage({ ...data, lastModified: new Date().toISOString(), status: 'draft' });
  },

  async loadDraft(): Promise<FracFormData | null> {
    return loadDraftFromStorage();
  },

  async clearDraft(): Promise<void> {
    clearDraftFromStorage();
  },

  async submit(data: FracFormData): Promise<SubmissionResult> {
    const reference = generateReferenceNumber();
    const submittedAt = new Date().toISOString();
    const breakdown = computeJobCostBreakdown(data.jobCost);

    saveSubmission({
      reference,
      submittedAt,
      data: { ...data, status: 'submitted' },
    });

    // Clear the draft once submitted
    clearDraftFromStorage();

    return {
      reference,
      submittedAt,
      company: data.company || 'Unknown',
      well: data.mainFracData.wellInfo.well,
      jobDate: data.mainFracData.wellInfo.jobDate,
      jobTotal: breakdown.total,
    };
  },
};
