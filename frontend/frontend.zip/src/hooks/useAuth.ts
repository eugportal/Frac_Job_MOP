import { useState } from 'react';
import type { Company } from '@/data/authCompanies';
import { isCompany } from '@/data/authCompanies';
import { requestOtp, verifyOtp, type AuthMethod, type OtpChallenge } from '@/services/authApi';

const SESSION_KEY = 'frac-data-session-v2';

interface AuthSession {
  company: Company;
  accessToken: string;
}

function loadSession(): AuthSession | null {
  try {
    const raw = sessionStorage.getItem(SESSION_KEY);
    if (!raw) return null;
    const session = JSON.parse(raw) as Partial<AuthSession>;
    return typeof session.accessToken === 'string' && typeof session.company === 'string' && isCompany(session.company)
      ? { company: session.company, accessToken: session.accessToken }
      : null;
  } catch {
    return null;
  }
}

export function useAuth() {
  const [session, setSession] = useState<AuthSession | null>(loadSession);

  const beginLogin = (authMethod: AuthMethod, username: string, password: string): Promise<OtpChallenge> => requestOtp(authMethod, username, password);

  const confirmOtp = async (challengeId: string, otp: string) => {
    const { accessToken, company } = await verifyOtp(challengeId, otp);
    if (!isCompany(company)) throw new Error('Your assigned company is not configured in this application.');
    const nextSession = { company, accessToken };
    sessionStorage.setItem(SESSION_KEY, JSON.stringify(nextSession));
    setSession(nextSession);
  };

  const logout = () => {
    sessionStorage.removeItem(SESSION_KEY);
    setSession(null);
  };

  return { company: session?.company ?? null, accessToken: session?.accessToken ?? null, beginLogin, confirmOtp, logout };
}
