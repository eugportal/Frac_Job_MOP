import { randomUUID } from 'node:crypto';
import type { PoolClient } from 'pg';
import { database } from './database.js';

export class FracJobError extends Error {
  constructor(public readonly statusCode: number, message: string) { super(message); }
}

export interface SessionUser {
  id: string;
  username: string;
  email: string;
  companyId: string;
  companyName: string;
  role: 'admin' | 'editor' | 'viewer';
  isSuperuser: boolean;
}

export async function findSessionUser(username: string, email?: string): Promise<SessionUser | null> {
  const result = await database.query<SessionUser>(
    `select u.id, u.username, u.email, c.id as "companyId", c.name as "companyName", m.role, u.is_superuser as "isSuperuser"
       from public.app_users u
       join public.company_memberships m on m.user_id = u.id
       join public.companies c on c.id = m.company_id
      where u.username = $1 and u.is_active and ($2::text is null or u.email = $2)
      order by m.created_at asc`, [username, email ?? null],
  );
  if (result.rows.length === 0) return null;
  if (result.rows.length > 1) throw new FracJobError(409, 'This account has multiple companies. Assign exactly one company before signing in.');
  return result.rows[0];
}

function nullable(value: unknown) { return value === '' || value === undefined ? null : value; }
function asArray(value: unknown) { return Array.isArray(value) ? value : []; }

async function requireWell(client: PoolClient, companyId: string, wellName: unknown) {
  if (typeof wellName !== 'string' || !wellName.trim()) return null;
  const result = await client.query<{ id: string }>('select id from public.wells where company_id = $1 and name = $2', [companyId, wellName]);
  if (!result.rows[0]) throw new FracJobError(400, 'The selected well does not belong to your company.');
  return result.rows[0].id;
}

export async function saveFracJob(user: SessionUser, form: any, submit: boolean) {
  const main = form.mainFracData ?? {};
  const wellInfo = main.wellInfo ?? {};
  const reports = main.reports ?? {};
  const reservoir = main.reservoir ?? {};
  const completion = form.completionData ?? {};
  const jobCost = form.jobCost ?? {};
  const jobId = typeof form.formId === 'string' && /^[0-9a-f-]{36}$/i.test(form.formId) ? form.formId : randomUUID();
  const client = await database.connect();
  try {
    await client.query('begin');
    const existing = await client.query<{ id: string; status: string }>('select id, status from public.frac_jobs where id = $1', [jobId]);
    if (existing.rows[0]?.status === 'submitted') throw new FracJobError(409, 'Submitted forms cannot be changed.');
    const wellId = await requireWell(client, user.companyId, wellInfo.well);
    const status = submit ? 'submitted' : (form.status === 'in-progress' ? 'in_progress' : 'draft');
    const job = await client.query<{ id: string; reference: string | null; submitted_at: string | null }>(
      `insert into public.frac_jobs (id, company_id, well_id, status, job_date, submitted_at, submitted_by, created_by,
           data_source_confidence, frac_vendor, technique, job_cost_enabled, job_cost_skipped, completion_enabled, completion_skipped)
       values ($1,$2,$3,$4,$5,case when $4 = 'submitted' then now() else null end,case when $4 = 'submitted' then $6 else null end,$6,$7,$8,$9,$10,$11,$12,$13)
       on conflict (id) do update set well_id=excluded.well_id, status=excluded.status, job_date=excluded.job_date,
           submitted_at=case when excluded.status = 'submitted' then now() else null end,
           submitted_by=case when excluded.status = 'submitted' then $6 else null end, data_source_confidence=excluded.data_source_confidence,
           frac_vendor=excluded.frac_vendor, technique=excluded.technique, job_cost_enabled=excluded.job_cost_enabled,
           job_cost_skipped=excluded.job_cost_skipped, completion_enabled=excluded.completion_enabled, completion_skipped=excluded.completion_skipped
       where public.frac_jobs.company_id = $2
       returning id, reference, submitted_at`,
      [jobId, user.companyId, wellId, status, nullable(wellInfo.jobDate), user.id, nullable(wellInfo.dataSourceConfidence), nullable(wellInfo.fracVendor), nullable(reports.technique), !!jobCost.enabled, !!jobCost.skipped, !!completion.enabled, !!completion.skipped],
    );
    if (!job.rows[0]) throw new FracJobError(404, 'Form not found for your company.');
    await client.query(
      `insert into public.job_reservoir_details (job_id, formation_name, lithology, well_type, pad_percent, mid_perf_tvd, number_of_perforations, max_deviation, average_reservoir_pressure, bhst, average_porosity, workbook_data)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)
       on conflict (job_id) do update set formation_name=excluded.formation_name, lithology=excluded.lithology, well_type=excluded.well_type, pad_percent=excluded.pad_percent, mid_perf_tvd=excluded.mid_perf_tvd, number_of_perforations=excluded.number_of_perforations, max_deviation=excluded.max_deviation, average_reservoir_pressure=excluded.average_reservoir_pressure, bhst=excluded.bhst, average_porosity=excluded.average_porosity, workbook_data=excluded.workbook_data`,
      [jobId, nullable(reservoir.formationName), nullable(reservoir.lithology), nullable(reservoir.wellType), nullable(reservoir.padPercent), nullable(reservoir.midPerfTVD), nullable(reservoir.numberOfPerfs), nullable(reservoir.maxDeviation), nullable(reservoir.averageReservoirPressure), nullable(reservoir.bhst), nullable(reservoir.averagePorosity), JSON.stringify({ ...main.workbookFields, wellEug: wellInfo.wellEug, field: wellInfo.field, regionArea: wellInfo.regionArea, latitude: wellInfo.latitude, longitude: wellInfo.longitude, onOffShore: wellInfo.onOffShore, rigName: wellInfo.rigName, reports })],
    );
    await client.query('delete from public.job_stages where job_id = $1', [jobId]);
    for (const stage of asArray(main.stages)) await client.query(
      'insert into public.job_stages (job_id, stage_number, perf_top, perf_bottom, pad_percent, fluid_volume, proppant_amount, rate, pressure) values ($1,$2,$3,$4,$5,$6,$7,$8,$9)',
      [jobId, stage.stage, nullable(stage.perfTop), nullable(stage.perfBottom), nullable(stage.padPercent), nullable(stage.fluidVolume), nullable(stage.proppantAmount), nullable(stage.rate), nullable(stage.pressure)],
    );
    await client.query('delete from public.job_completion_records where job_id = $1', [jobId]);
    for (const record of asArray(completion.records)) await client.query(
      `insert into public.job_completion_records (job_id, well_name_uwi, well_type, casing_size, tubing_dp_size, tubing_dp_grade, perf_interval_top, perf_interval_bottom, entrance_hole_size, completion_type, prior_workovers, triple_compo_log, cpi_log, workbook_data)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12,$13,$14)`,
      [jobId, record.wellNameUWI || wellInfo.well || 'Not provided', record.wellType || 'Not provided', nullable(record.casingSize), nullable(record.tubingDPSize), nullable(record.tubingDPGrade), nullable(record.perfIntervalTop), nullable(record.perfIntervalBottom), nullable(record.entranceHoleSize), nullable(record.completionType), nullable(record.priorWorkovers), nullable(record.tripleCompoLog), nullable(record.cpiLog), JSON.stringify(record.workbookFields ?? {})],
    );
    await client.query('delete from public.job_cost_lines where job_id = $1', [jobId]);
    const categories: Array<[string, string]> = [['fracMaterial', 'frac_material'], ['gelChemicals', 'gel_chemicals'], ['crossLinkedGel', 'cross_linked_gel'], ['sandPlug', 'sand_plug'], ['fracEquipment', 'frac_equipment'], ['fracDHT', 'frac_dht'], ['cleanOut', 'clean_out'], ['additional', 'additional']];
    for (const [key, category] of categories) for (const [index, line] of asArray(jobCost[key]).entries()) await client.query(
      `insert into public.job_cost_lines (job_id, category, sort_order, invoice_no, description, invoice_amount, quantity, unit, unit_price, pumping_charge, related_cost, remarks)
       values ($1,$2,$3,$4,$5,$6,$7,$8,$9,$10,$11,$12)`,
      [jobId, category, index, nullable(line.invoiceNo), nullable(line.description), nullable(line.invoiceAmount), nullable(line.quantity), nullable(line.unit), nullable(line.unitPrice), nullable(line.pumpingCharge), nullable(line.relatedCost), nullable(line.remarks)],
    );
    await client.query('delete from public.job_cost_workbook_rows where job_id = $1', [jobId]);
    for (const [index, row] of asArray(jobCost.workbookRows).entries()) await client.query('insert into public.job_cost_workbook_rows (job_id, sort_order, values) values ($1,$2,$3)', [jobId, index, JSON.stringify(row.values ?? {})]);
    if (submit && !job.rows[0].reference) await client.query(`update public.frac_jobs set reference = 'FRAC-' || to_char(now(), 'YYYYMMDD') || '-' || upper(substr(replace(id::text, '-', ''), 1, 6)) where id = $1`, [jobId]);
    const final = await client.query<{ reference: string; submitted_at: string | null }>('select reference, submitted_at from public.frac_jobs where id = $1', [jobId]);
    await client.query('commit');
    return { formId: jobId, reference: final.rows[0].reference, submittedAt: final.rows[0].submitted_at, company: user.companyName, well: wellInfo.well ?? '', jobDate: wellInfo.jobDate ?? '', jobTotal: asArray(jobCost.fracMaterial).concat(asArray(jobCost.gelChemicals), asArray(jobCost.crossLinkedGel), asArray(jobCost.sandPlug)).reduce((sum: number, line: any) => sum + Number(line.invoiceAmount ?? 0) + Number(line.pumpingCharge ?? 0) + Number(line.relatedCost ?? 0), 0) + ['fracEquipment','fracDHT','cleanOut','additional'].flatMap((key) => asArray(jobCost[key])).reduce((sum: number, line: any) => sum + Number(line.total ?? ((Number(line.quantity) || 0) * (Number(line.unitPrice) || 0))), 0) };
  } catch (error) {
    await client.query('rollback').catch(() => undefined);
    throw error;
  } finally { client.release(); }
}
